public interface AnimalAquatico {
    public void nadar();
}
