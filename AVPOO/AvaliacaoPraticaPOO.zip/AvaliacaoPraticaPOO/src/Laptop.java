public class Laptop {
    int RAM;
}
