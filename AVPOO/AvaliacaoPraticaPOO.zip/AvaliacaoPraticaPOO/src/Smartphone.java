public class Smartphone extends ProdutoEletronico{
    String Sys;
}
