public class TV extends ProdutoEletronico{
    double Tela;
}
