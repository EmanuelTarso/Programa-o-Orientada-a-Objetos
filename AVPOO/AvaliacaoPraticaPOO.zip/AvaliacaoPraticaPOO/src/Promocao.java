public interface Promocao {
    public double calcDesconto(double percentual);
}
